--
-- PostgreSQL database dump
--

\restrict j4epIjf8d35BnW5aqrH6FLcg3j3O2OeIYQg74xxfVfFbGTFTeYb69AT1RfZP3o4

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict j4epIjf8d35BnW5aqrH6FLcg3j3O2OeIYQg74xxfVfFbGTFTeYb69AT1RfZP3o4

